
public class MyZoo_main {
	public static void main(String [] args)
	{
		MyZoo x = new MyZoo();
	}
}
